"""
This file is used to store non changing constants
"""
BASE_URL_V1 = "https://the-one-api.herokuapp.com/v1/"
BASE_URL_V2 = "https://the-one-api.dev/v2"
