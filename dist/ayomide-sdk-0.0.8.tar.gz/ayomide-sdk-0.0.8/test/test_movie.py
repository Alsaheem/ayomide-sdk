import pytest

"""
This is a framework of the test for the movie api endpoint
"""


def test_can_call_movie_api_without_params():
    assert True == True


def test_can_call_movie_api_with_params():
    assert True == True


def test_can_call_movie_api_with_filters():
    assert True == True


def test_can_call_movie_api_with_params_and_filters():
    assert True == True
