import pytest

"""
This is a framework of the test for the client class
"""


def test_can_initialize_client_with_apikey():
    assert True == True


def test_cannot_initialize_client_without_api_key():
    assert True == True


def test_can_initialize_client_without_version():
    assert True == True
